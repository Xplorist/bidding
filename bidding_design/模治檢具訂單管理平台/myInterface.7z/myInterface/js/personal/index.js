new Vue({
  el: '#app',
  data: function() {
    return {
    	// 環形進度條
    	progress: {
	    	strokeWidth: 12,
	    	width: 100,
	    	color: '#0096FF'
    	},
    }
  },
  methods: {
  }
})
