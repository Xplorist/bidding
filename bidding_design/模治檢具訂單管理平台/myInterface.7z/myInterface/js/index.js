new Vue({
  el: '#app',
  data: function() {
    return { visible: false }
  }
})
